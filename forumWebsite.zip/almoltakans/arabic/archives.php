<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
$_SESSION['multakans_page']='archives_id';
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php include "includes/meta.php";?>
<link rel="stylesheet" type="text/css" href="includes/css.css">
<title>الملتقى النسائي - الارشيف</title>
<meta name="description" content="الحملة العالمية للتعليم : في قلب من EFA ( التعليم للجميع ) الشراكة هو الاعتقاد بأن التعليم هو مفتاح التنمية المستدامة والسلام والاستقرار داخل و بين "/>

<script type="text/javascript" src="includes/js.js"></script>
	<script type="text/javascript" src="jssor3/lib3/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="jssor3/lib3/jssor.slider.debug.js"></script>
	<script type="text/javascript" src="jssor3/lib3/jssor.slider.mini.js"></script>
	<script type="text/javascript" src="lib/jquery-1.10.1.min.js"></script>
    <script type="text/javascript" src="lib/jquery.fancybox1.js?v=2.1.5"></script>
    <link rel="stylesheet" type="text/css" href="lib/jquery.fancybox1.css?v=2.1.5" media="screen" />
	
	
<?php include "includes/hover.php"; ?>

	
	<script>
    $(document).ready(function() {
    $('.fancybox').fancybox({padding:0});
    });
    </script>
</head>

<body>

<div class="body_home">
<!-----------------------------------------------------------------HEADER BEGIN------------------------------------->


<?php include "includes/header.php"; ?>



<!-------------------------------------------------------------------ARCHIVES CONTENT  START------------------------------------->
		 <?php
		 include 'db/db.php';
		 $sql_archives="select * from archives where status='1' order by id DESC";
		 $res_archives=mysql_query($sql_archives);
		 $result_archives=mysql_fetch_array($res_archives);
		  ?>
		  
		 <?php
		 include 'db/db.php';
		 $sql_pages_photos="select * from pages_photos where title = 'archives'";
		 $res_pages_photos=mysql_query($sql_pages_photos);
		 $result_pages_photos=mysql_fetch_array($res_pages_photos);
		  ?>
		  

<style>
.fancybox-custom .fancybox-skin {
		
box-shadow: 0 0 50px #222;
}
body1 {

max-width: 700px;
margin: 0 auto;
}
</style>


<div class="content_archives">


<img class="archives_photo1" src="../uploads/<?=$result_pages_photos['image']?>" alt="<?=$result_pages_photos['image']?>" width="785" height="237"/>

<div class="archives_archives">أرشيف</div>



			 <?php
		    include 'db/db.php';
		    $sql_archives="select * from archives where status='1' order by id asc";
		    $res_archives=mysql_query($sql_archives);
		    while($result_archives=mysql_fetch_array($res_archives))
			{ ?> 

<div class="article_pos">

<div class="educational_teachinghours">
<?=$result_archives['title_ar']?>
</div>
<div class="educational_teachinghours_txt">
<?=$result_archives['content_ar']?>
</div>

</div>

<div class="article_pos1">
<div class="archives_readmore1_3rd"><p class="archives_readmore11_3rd"><?=$result_archives['subtitle_ar']?></p></div>
<a class="fancybox fancybox.ajax" href="includes/fancybox_content2.php?id=<?=$result_archives['id']?>"><img class="archives_readmore_3rd" src="icons/archives_readmore.png" /></a>
<div class="archives_readmore_txt_3rd"><a style="color:#c10171; text-decoration:none;" class="fancybox fancybox.ajax" href="includes/fancybox_content2.php?id=<?=$result_archives['id']?>">اقرأ المزيد.</a></div>
</div>


             <?php }
			 ?>



</div>

 <!-------------------------------------------------------------------ARCHIVES CONTENT  END------------------------------------->
 
 
 
<!-------------------------------------------------------------------FOOTER BEGIN------------------------------------->

 <?php include "includes/footer.php"; ?>




</div>

</body>
</html>