    <?php
	include '../db/db.php';
	if(isset($_POST['country_id'])){
	$code=$_POST['country_id'];
	}
	else{$code='';}
	
	
    $sql=mysql_query("INSERT INTO country(code)VALUES('$code')") or die(mysql_error());
   if(!$sql){
	   echo $sql;
	   }
	   else {
		echo 1;
			}
    ?>