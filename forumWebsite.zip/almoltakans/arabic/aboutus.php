<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
$_SESSION['multakans_page']='aboutus_id';
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php include "includes/meta.php";?>
<link rel="stylesheet" type="text/css" href="includes/css.css">
<title>الملتقى النسائي - نبذة عنا</title>
<meta name="description" content="هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز"/>
<script type="text/javascript" src="includes/js.js"></script>
<script type="text/javascript" src="jssor/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="jssor/js/jssor.slider.mini.js"></script>




<?php include "includes/hover.php"; ?>



<script>
$(document).ready(function() {
$('.fancybox').fancybox({padding:0});
});
</script>
</head>

<body>

<div class="body_home">
<!-----------------------------------------------------------------HEADER BEGIN------------------------------------->


<?php include "includes/header.php"; ?>



<!-------------------------------------------------------------------ABOUTUS CONTENT  START------------------------------------->
		 <?php
		 include 'db/db.php';
		 $sql_aboutus="select * from aboutus where status='1' order by id DESC";
		 $res_aboutus=mysql_query($sql_aboutus);
		 $result_aboutus=mysql_fetch_array($res_aboutus);
		  ?>


		  <?php
		 include 'db/db.php';
		 $sql_pages_photos="select * from pages_photos where title = 'aboutus'";
		 $res_pages_photos=mysql_query($sql_pages_photos);
		 $result_pages_photos=mysql_fetch_array($res_pages_photos);
		  ?>
		  
		  
<div class="content_aboutus">


<img class="aboutus_photo1" src="../uploads/<?=$result_pages_photos['image']?>" alt="<?=$result_pages_photos['image']?>" width="785" height="237"/>

<div class="womensforum">
<div class="womensforum_txt">المرأة منتدى المستخدمين</div>
<div class="womensforum_txt1">
<?=$result_aboutus['content_ar']?></div>
</div>


<div class="members">


<?php
include 'db/db.php';
$start=0;
$limit=8;

if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$start=($id-1)*$limit;
}
else{
	$id=1;
}
?>


			<?php
			$sql_members="select * from members where status='1' order by id ASC LIMIT $start, $limit";
		    $res_members=mysql_query($sql_members);
	    	$counter = 0;	
			while( $result_members=mysql_fetch_array($res_members)){ ?>
			

			<?php
				
				 if ( ($counter) % 2 == 0 )
				 { $counter+=1;	?>


<div class="member1">
<div class="members_photos"><img class="member1_photo" src="../uploads/<?=$result_members['image']?>" alt="<?=$result_members['image']?>" /></div>
<div class="members_text">
<p class="members_position"><?=$result_members['title_ar']?></p>
<div class="members_detail1">
<p class="members_detail"><?=$result_members['content_ar']?></p>
</div>
</div>
</div>

			<?php }
			else {$counter+=1;
			 ?>

<div class="member5">
<div class="members_photos"><img class="member5_photo" src="../uploads/<?=$result_members['image']?>" alt="<?=$result_members['image']?>" /></div>
<div class="members_text">
<p class="members_position"><?=$result_members['title_ar']?></p>
<div class="members_detail1">
<p class="members_detail"><?=$result_members['content_ar']?></p>
</div>
</div>
</div>

			 <?php }}
			 ?>


<?php
$rows=mysql_num_rows(mysql_query("select * from members where status='1' order by id ASC"));			 
$total=ceil($rows/$limit);	?>		 
			 
<div class="page_no1">			 
<?php if($id>1)
{
	echo "<a   href='?id=".($id-1)."' class='button_link1'>السابق</a>";
}
if($id!=$total)
{
	echo "<a href='?id=".($id+1)."' class='button_link1'>التالي</a>";
}
?>

<?php
		for($i=1;$i<=$total;$i++)
		{
			if($i==$id) { echo "<a class='pagin_no'>".$i."</a>"; }
			
			else { echo "<a class='pagin_no' href='?id=".$i." '>  ".$i."&nbsp;"; }
		}
?>
</div>




</div>




</div>

 <!-------------------------------------------------------------------ABOUTUS CONTENT  END------------------------------------->
 
 
 
 
 <!-----------------------------------------------------------------FOOTER BEGIN------------------------------------->
 
 <?php include "includes/footer.php"; ?>




</div>

</body>
</html>