    <?php
	session_start();
	include '../db/db.php';
	$username=$_SESSION['login_user'];
    $comment=$_POST['text_id'];
    $sql=mysql_query("INSERT INTO comment_ourgoals(username, comment)VALUES('$username', '$comment')") or die(mysql_error());
   if(!$sql){
	   echo $sql;
	   }
	   else { echo 1;}
    ?>