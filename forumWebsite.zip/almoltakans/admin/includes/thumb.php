<?php
function makeThumbnails($old_width,$old_height,$nw, $img, $tumb)
{
    $thumbnail_width = $nw;
	$per=($nw*100)/$old_width;
    $thumbnail_height = round(($per*$old_height)/100);
    $thumb_beforeword = "thumb";
    $arr_image_details = getimagesize($img); // pass id to thumb name
    $original_width = $arr_image_details[0];
    $original_height = $arr_image_details[1];
    if ($original_width > $original_height) {
        $new_width = $thumbnail_width;
        $new_height = intval($original_height * $new_width / $original_width);
    } else {
        $new_height = $thumbnail_height;
        $new_width = intval($original_width * $new_height / $original_height);
    }
    $dest_x = intval(($thumbnail_width - $new_width) / 2);
    $dest_y = intval(($thumbnail_height - $new_height) / 2);
    if ($arr_image_details[2] == 1) {
        $imgt = "ImageGIF";
        $imgcreatefrom = "ImageCreateFromGIF";
    }
    if ($arr_image_details[2] == 2) {
        $imgt = "ImageJPEG";
        $imgcreatefrom = "ImageCreateFromJPEG";
    }
    if ($arr_image_details[2] == 3) {
        $imgt = "ImagePNG";
        $imgcreatefrom = "ImageCreateFromPNG";
    }
    if ($imgt) {
        $old_image = $imgcreatefrom($img);
		
        $new_image = imagecreatetruecolor($thumbnail_width, $thumbnail_height);
		$alpha_channel = imagecolorallocatealpha($new_image, 0, 0, 0, 127); 
		imagecolortransparent($new_image, $alpha_channel); 
		imagefill($new_image, 0, 0, $alpha_channel);
        imagecopyresized($new_image, $old_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
		 imagesavealpha($new_image,true); 
		/**
		$img imagecreatetruecolor(900, 350);
		$color = imagecolorallocatealpha($imgb, 0, 0, 0, 127); //fill transparent back
		imagefill($img, 0, 0, $color);
		imagesavealpha($imgb, true);
		**/
        $imgt($new_image, $tumb);
    }
}

function after ($this, $inthat)
    {
        if (!is_bool(strpos($inthat, $this)))
        return substr($inthat, strpos($inthat,$this)+strlen($this));
    };
?>