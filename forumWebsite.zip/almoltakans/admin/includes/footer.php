<div class="header_border">&nbsp;</div>
<div id="footer" class="footerlnk">
<div>
 &copy; Copyright 2012 - <a href="http://www.browse-me.net">Browse-me</a> -  All rights Reserved
 </div>
</div> 