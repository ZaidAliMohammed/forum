<STYLE>
#accordion {
	list-style: none;
}
#accordion li{
	display: block;
	font-weight: bold;
	cursor: pointer;
	list-style: circle;
}
#accordion ul {
	list-style: none;
	padding: 0 0 0 0;
	display: none;
	width:100%;
}
#accordion ul li{
	font-weight: normal;
	cursor: auto;
	padding-left:10%;
	width:90%;
	background:#ddd;
}
#accordion a {
	text-decoration: none;
}
#accordion a:hover {
	text-decoration: underline;
}
</STYLE>
<div class="bcl">&nbsp;</div>
<ul id="accordion" class="menuleft" style="margin:0; padding:0;">
		  <li class="menuleft_b">Categories</li>
		  <li class="menuleft_a" id="aboutus"><a href="aboutus.php">About Us Page</a></li>
		  <li class="menuleft_a" id="members"><a href="members.php">About Us Page: Members</a></li>
          <li class="menuleft_a" id="education"><a href="education.php">Education Page</a></li>
		  <li class="menuleft_a" id="ourwork"><a href="ourwork.php">Our Work Page</a></li>
		  <li class="menuleft_a" id="archives"><a href="archives.php">Archives Page</a></li>
		  <li class="menuleft_a" id="ourgoals"><a href="ourgoals.php">Our Goals Page</a></li>
		  <li class="menuleft_a" id="ourgoals_photos"><a href="ourgoals_photos.php">Our Goals Page: Photos</a></li>
		  <li class="menuleft_a" id="header1"><a href="header.php">Pages: Header</a></li>
		  <li class="menuleft_a" id="pages_photos"><a href="pages_photos.php">Pages: Photos</a></li>
		  <li class="menuleft_a" id="image_sliders"><a href="image_sliders.php">Sliders: Home & Education</a></li>
		  <li class="menuleft_a" id="image_sliders_ourwork"><a href="image_sliders_ourwork.php">Sliders: Ourwork</a></li>
		  <li class="menuleft_a" id="register"><a href="register.php">Register: Users</a></li>
		  <li class="menuleft_a" id="register_companies"><a href="register_companies.php">Register: Companies</a></li>
		  <li class="menuleft_a" id="comment1"><a href="comment1.php">Comment: Our Work</a></li>
		  <li class="menuleft_a" id="comment2"><a href="comment2.php">Comment: Our Goals</a></li>
		  <li class="menuleft_a" id="like"><a href="like.php">Like: Education Situation</a></li>
		  <li class="menuleft_a" id="newsletter"><a href="newsletter.php">Newsletter</a></li>
          <li class="menuleft_a" id="users"><a href="users.php">User Manager</a></li>
	</ul>
</ul>
<SCRIPT>
var page='<?=$_SESSION['admin']?>';
$(".menuleft_a").css({'background':'none'});
if(page=='city'){
	$("#country").css({'background':'#fff'});
}else if(page=='details'){
	$("#packages").css({'background':'#fff'});
}
else{
$("#"+page).css({'background':'#fff'});
}

</SCRIPT>