<div id="header_index">
    <div id="header-login" style="height:31px;"></div>
	<div id="header-content">
		 <div id="header-logo">
			 <img src="assets/images/be_header/header_logo.png" />
		</div>
         <div class="header_midel">&nbsp;</div>
        <div class="header_right"><?=date('l d / M / Y');?></div>
	</div>
    <div class="header_border">&nbsp;</div>
	<div id="header-border">&nbsp;</div>
</div>