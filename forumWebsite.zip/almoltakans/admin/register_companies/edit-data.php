<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$contact_person=$_POST['contact_person'];
$company_name=$_POST['company_name'];
$password=$_POST['password'];
$postal_code=$_POST['postal_code'];
$country=$_POST['country'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$username=$_POST['usernamer_id'];
$status=secureInput($_POST['status']);
if($main ==''){
	echo '<div class="error">Please insert username</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `register_companies` set contact_person='$contact_person', company_name='$company_name', password='$password', postal_code='$postal_code', country='$country', mobile='$mobile', email='$email', phone='$phone', address='$address', username='$username' where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>