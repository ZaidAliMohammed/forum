<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$main=($_POST['firstname']);
$main1=($_POST['lastname']);
$password=($_POST['password']);
$country=($_POST['country']);
$mobile=($_POST['mobile']);
$phone=($_POST['phone']);
$email=($_POST['email']);
$website=($_POST['website']);
$status=secureInput($_POST['status']);
if($main ==''){
	echo '<div class="error">Please insert username</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `register` set fullname='$main', lastname='$main1', password='$password', country='$country', mobile='$mobile', email='$email', phone='$phone', website='$website' where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>