<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from   register where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>
	<div id="preview"></div>
	<form action="register/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
					 
					  <label>username</label>
					 <input type="text" name="fullname" id="fullname" value="<?=$rr['fullname']?>" class="inptext" />
					 <input type="text" name="lastname" id="lastname" value="<?=$rr['lastname']?>" class="inptext" />
					 <input type="text" name="password" id="password" value="<?=$rr['password']?>" class="inptext" />
					 <input type="text" name="country" id="country" value="<?=$rr['country']?>" class="inptext" />
					 <input type="text" name="mobile" id="mobile" value="<?=$rr['mobile']?>" class="inptext" />
					 <input type="text" name="phone" id="phone" value="<?=$rr['phone']?>" class="inptext" />
					 <input type="text" name="email" id="email" value="<?=$rr['email']?>" class="inptext" />
					 <input type="text" name="website" id="website" value="<?=$rr['website']?>" class="inptext" />
					
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="<?=$rr['status']?>">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>