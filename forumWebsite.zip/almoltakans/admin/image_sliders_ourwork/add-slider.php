<?php
include('../../db/db.php');
include ('../includes/thumb.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$status=secureInput($_POST['status']);
	
	
	//secureInput($_POST['page_s']);
	$file=$_FILES['file']['name'];
	$file2=$_FILES['file2']['name'];
	if($title=='' or $status=='' or $file=='' or $file2=='')
	echo '<div class="error">Please insert all the required field (*)</div>';
	else{
		$typefile=array('jpg','png','jpeg');
		$maxsize=800;
		$maxwidth=1200;
		$filesize=$_FILES['file']['size'];
		$filetype=after('.',$_FILES['file']['name']);
		$filesave='../../uploads/';
		$filesave2='../../uploads/';
		$data = mysql_real_escape_string($_FILES['file']['tmp_name']);
		$size1 = getimagesize($data);
		$width = $size1[0];
		$height = $size1[1];
						$width2 = $size1[0];
		$height2 = $size1[1];	
		$filesize2=$_FILES['file2']['size'];
		$filetype2=after('.',$_FILES['file2']['name']);
		$data2 = mysql_real_escape_string($_FILES['file2']['tmp_name']);				
					
					
					
		if($filesize>$maxsize*1000)
		{
			$result='<div class="error">the size of '.$file.' less 800 kb</div>';
			$result2='<div class="error">the size of '.$file2.' less 800 kb</div>';
		}else{
			if(!in_array($filetype,$typefile,$filetype2))
			
			{
				$result='<div class="error">the type of '.$filetype.' not specified in List</div>';
				$result2='<div class="error">the type of '.$filetype2.' not specified in List</div>';
			}else{
				$filename=date("mdYHis").".".$filetype;
				$filetumb='../../uploads/thumb/'.$filename;
				$filename2=date("mdYsi").".".$filetype2;
				$filetumb2='../../uploads/thumb/'.$filename2;
				if(!move_uploaded_file($_FILES['file']['tmp_name'],$filesave.$filename) or !move_uploaded_file($_FILES['file2']['tmp_name'],$filesave2.$filename2))
				{
					$result='<div class="error">the file '.$filename.' not Uploaded</div>';
					$result2='<div class="error">the file '.$filename2.' not Uploaded</div>';
				}else{
				
				makeThumbnails($width,$height,$maxwidth,$filesave.$filename,$filetumb);
				makeThumbnails($width,$height,$maxwidth,$filesave2.$filename2,$filetumb2);
		$q6=mysql_query("insert into  image_sliders_ourwork (title,status,image,image2) values('$title','$status','$filename','$filename2')") or die(mysql_error());
		echo'<div class="success">Content was added successfully.</div>';
				}
			}
		}
	}
	
 }
?>