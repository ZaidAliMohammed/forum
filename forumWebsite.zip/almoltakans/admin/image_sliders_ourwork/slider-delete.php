<?php
require_once('../../db/db.php');
if($_POST['delete'])
	{
		$checkbox = $_POST['checkbox'];
		$countCheck = count($_POST['checkbox']);
		for($i=0;$i<$countCheck;$i++)
		{               $del_id  = $checkbox[$i];
			            $query = "SELECT * FROM  image_sliders_ourwork WHERE `id`={$del_id}";
						$result = mysql_query($query);
						
						while($row = mysql_fetch_array($result)) {
								$fileToRemove = '../../uploads/'.$row['image'];
								$fileToRemove = '../../uploads/'.$row['image2'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
								$fileToRemove = '../../uploads/thumb/'.$row['image'];
								$fileToRemove = '../../uploads/thumb/'.$row['image2'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
						}

			$q1 = mysql_query("DELETE FROM `image_sliders_ourwork` WHERE id = '$del_id'");
			
		}
		header("Location: ../image_sliders_ourwork.php");
	}
?>