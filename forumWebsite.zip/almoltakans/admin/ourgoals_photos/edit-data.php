<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$main=($_POST['title']);
$status=secureInput($_POST['status']);

if($main ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `ourgoals_photos` set title='$main' where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>