<?php
require_once('../../db/db.php');
if($_POST['delete'])
	{
		$checkbox = $_POST['checkbox'];
		$countCheck = count($_POST['checkbox']);
		for($i=0;$i<$countCheck;$i++)
		{               $del_id  = $checkbox[$i];
			            $query = "SELECT * FROM  newsletter WHERE `id`={$del_id}";
						$result = mysql_query($query);
						

			$q1 = mysql_query("DELETE FROM `newsletter` WHERE id = '$del_id'");
			
		}
		header("Location: ../newsletter.php");
	}
?>