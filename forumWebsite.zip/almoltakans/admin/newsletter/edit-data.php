<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$main=($_POST['fullname']);
$status=secureInput($_POST['status']);
$email=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['email']);
if($main ==''){
	echo '<div class="error">Please insert username</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `newsletter` set fullname='$main', email='$email' where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>