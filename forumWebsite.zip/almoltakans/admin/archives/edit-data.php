<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$main=($_POST['title']);
$main_ar=($_POST['title_ar']);
$submain=($_POST['subtitle']);
$submain_ar=($_POST['subtitle_ar']);
$status=secureInput($_POST['status']);
$content=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content']);
$content_ar=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content_ar']);
if($main =='' || $main_ar =='' || $submain ==''  || $submain_ar  ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `archives` set title='$main', title_ar='$main_ar', subtitle='$submain', subtitle_ar='$submain_ar', content='$content', content_ar='$content_ar'   where id='$id'") or die (mysql_error());

  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>