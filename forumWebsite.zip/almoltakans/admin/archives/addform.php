	<div id="preview"></div>
	<form action="archives/add-slider.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				   <div id="leftform">
	            <div id="preview"></div>
					
                    
                     <label>Title</label>
					 <input type="text" name="title" id="title" value="" class="inptext" />
					 <label>Title Arabic</label>
					 <input type="text" name="title_ar" id="title_ar" value="" class="inptext" />
					 <label>Subitle</label>
					 <input type="text" name="subtitle" id="subtitle" value="" class="inptext" />
					 <label>Subitle Arabic</label>
					 <input type="text" name="subtitle_ar" id="subtitle_ar" value="" class="inptext" />
					  
					  
					  
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
                      
                         
					  <label>Content</label><textarea name="content" id="content" class="txtarea"></textarea>
					  <label>Content Arabic</label><textarea name="content_ar" id="content_ar" class="txtarea"></textarea>
						 

				   </div>
				   <div id="bottomform">
					
				<input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
				   </div>
			</form>
