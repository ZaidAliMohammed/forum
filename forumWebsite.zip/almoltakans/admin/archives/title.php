<?php
include_once '../../db/db.php';
if(isset($_POST['id'])) { 
$id = intval($_POST['id']); 
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {						
$q31 = mysql_query("SELECT * FROM archives WHERE `id`='$id'");
$r31=mysql_fetch_array($q31);
	
if($r31['title']=='1'){
	$q41 = mysql_query("UPDATE archives SET `title`='1' WHERE `id`='$id'");
	echo '<img src="assets/icons/cross.png" />';}
	
else if ($r31['title']=='2')
{$q51 = mysql_query("UPDATE archives SET `title`='2' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	

else
{$q61 = mysql_query("UPDATE archives SET `title`='3' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';	
}

}
}
?>