<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from   archives where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>
	<div id="preview"></div>
	<form action="archives/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
					 
                     <label>Title</label>
					 <input type="text" name="title" id="title" value="<?=$rr['title']?>" class="inptext" />
					 <label>Title Arabic</label>
					 <input type="text" name="title_ar" id="title_ar" value="<?=$rr['title_ar']?>" class="inptext" />
					 <label>Subitle</label>
					 <input type="text" name="subtitle" id="subtitle" value="<?=$rr['subtitle']?>" class="inptext" />
					 <label>Subitle Arabic</label>
					 <input type="text" name="subtitle_ar" id="subtitle_ar" value="<?=$rr['subtitle_ar']?>" class="inptext" />
					
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="<?=$rr['status']?>">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
						 <label>Content</label><textarea name="content" id="content" class="txtarea"><?=$rr['content']?></textarea>
						 <label>Content Arabic</label><textarea name="content_ar" id="content_ar" class="txtarea"><?=$rr['content_ar']?></textarea>
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>