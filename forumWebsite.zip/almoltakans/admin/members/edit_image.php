e<?php
include('../../db/db.php');
include ('../includes/thumb.php');
if (isset ($_FILES['myfile'])) {
$id = intval($_GET['id']);	
$savefolder = "../../uploads/";
$max_size = 1000;
$min_size=10;
$max_width=800;	

$q2=mysql_query("SELECT * FROM `members` WHERE id='$id'");
  $row2=mysql_fetch_array($q2);
  $numrow2=mysql_num_rows($q2);
  if($row2['image']!=''){
  $fileToRemove2 = '../../uploads/'.$row2['image'];
								if (file_exists($fileToRemove2)) {
											unlink($fileToRemove2);
								}
  $fileToRemove3 = '../../uploads/thumb/'.$row2['image'];
								if (file_exists($fileToRemove3)) {
											unlink($fileToRemove3);
								}
  }
  $allowtype = array('bmp', 'gif', 'jpg', 'jpeg', 'png','swf');
  $type = end(explode(".", strtolower($_FILES['myfile']['name'])));
  if (in_array($type, $allowtype)) {
    // check its size
	if ($_FILES['myfile']['size']>=$min_size*1000 and $_FILES['myfile']['size']<=$max_size*1000) {
		$name = mysql_real_escape_string($_FILES['myfile']['name']); 
			$mime = mysql_real_escape_string($_FILES['myfile']['type']); 
			$data = mysql_real_escape_string($_FILES['myfile']['tmp_name']); 
			$size = intval($_FILES['myfile']['size']);
			
			$random_digit=rand(0000,9999);
			$new_file_name=$random_digit.$name;
			$filetumb='../../uploads/thumb/'.$new_file_name;	
      // if no errors
      if ($_FILES['myfile']['error'] == 0) {
        		$image = str_replace(' ','_',$new_file_name);
					$size1 = getimagesize($data);
					$width = $size1[0];
					$height = $size1[1];

			 $q6 = mysql_query("UPDATE `members` SET `image`='$image' where `id`='$id'") or die (mysql_error());
			 if($q6)
			 {
						 $thefile = $savefolder . "/" . $image;	
							// if the file can`t be uploaded, return a message
						if (!move_uploaded_file ($_FILES['myfile']['tmp_name'], $thefile)) {
						 echo 'The file can`t be uploaded, try again.';
						}else{
							makeThumbnails($width,$height,$max_width,$thefile,$filetumb);
							echo "Success Edit";
							
							}
        	
		       }

    }
	}
	else { echo 'The file <b>'. $_FILES['myfile']['name']. '</b> not between .<i>'.$min_size.' and  <i>'. $max_size. 'KB</i>'; }
  }
  else { echo 'The file <b>'. $_FILES['myfile']['name']. '</b> has not an allowed extension.'; }
  }
?>