<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from   pages_photos where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>
	<div id="preview"></div>
	<form action="pages_photos/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
					 
					  <label>Title</label>
					         <select name="title" class="inpselect">
                             <option value="<?=$rr['title']?>">Select Title</option>
							 <option value="home">Home Photo</option>
                             <option value="aboutus">About Us Photo</option>
                             <option value="education">Education Photo</option>
							 <option value="ourwork">Ourwork Photo</option>
                             <option value="archives">Archives Photo</option>
                             <option value="ourgoals">Our Goals Photo</option>
							 <option value="contactus">Contact Us Photo</option>
                             <option value="support">Support Photo</option>
							 <option value="register">Register Photo</option>
                         </select>
					
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="<?=$rr['status']?>">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
						 
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>