<?php
include_once '../../db/db.php';
if(isset($_POST['id'])) { 
$id = intval($_POST['id']); 
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {						
$q31 = mysql_query("SELECT * FROM pages_photos WHERE `id`='$id'");
$r31=mysql_fetch_array($q31);
	
if($r31['status']=='home'){
	$q41 = mysql_query("UPDATE pages_photos SET `title`='home' WHERE `id`='$id'");
	echo '<img src="assets/icons/cross.png" />';}
	
else if ($r31['title']=='aboutus')
{$q51 = mysql_query("UPDATE pages_photos SET `title`='aboutus' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	

else if ($r31['title']=='education')
{$q61 = mysql_query("UPDATE pages_photos SET `title`='education' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='ourwork')
{$q71 = mysql_query("UPDATE pages_photos SET `title`='ourwork' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='archives')
{$q81 = mysql_query("UPDATE pages_photos SET `title`='archives' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='ourgoals')
{$q91 = mysql_query("UPDATE pages_photos SET `title`='ourgoals' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='contactus')
{$q101 = mysql_query("UPDATE pages_photos SET `title`='contactus' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='support')
{$q105 = mysql_query("UPDATE pages_photos SET `title`='support' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else
{$q111 = mysql_query("UPDATE pages_photos SET `title`='register' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	
}
}
?>