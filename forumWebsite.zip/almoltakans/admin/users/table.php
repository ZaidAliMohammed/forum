 <?php
 if(!isset($_SESSION)){
	 session_start();
	 include "../../db/db.php";
	 ?>
     <script type="text/javascript">
	$(document).ready(function() { 
		$('#listcontent').dataTable( {
		  "aoColumnDefs": [
			  { 'bSortable': false, 'aTargets': [ 4 ] }
		   ]
		});
	});
	</script>
     <?php
 }?>
 
   <table cellpadding="0" cellspacing="0" border="0" class="table-list display" id="listcontent">               
                <thead>
                    <tr valign="top">
                        <th align="left">ID</th>
						<th align="left">Name</th>
						<th align="left">Email</th>
						<th align="left">Status</th>
                        <?php if(($_SESSION['control_of_user'])!='User'){ ?>
                        <th>Delete <input id="CheckAll" onclick="checkAll();" name="CheckAll" type="checkbox" /></th>
                        <?php } ?>
                    </tr>
                </thead>
				<tbody>
					<?php 
					 $q=mysql_query("select * from users order by id ASC");
					while($r=mysql_fetch_array($q)){ ?>
					 <tr id="<?=$r['id'];?>">
					   <td><?=$r['id'];?></td>
					   <td onclick="getEdit('users/editForm.php?id=<?=$r['id'];?>',<?=$r['id'];?>)" class="pointertd"><?=substr($r['name'],0,10);?>..</td>
					   <td><?php echo $r['email'];?></td>
					   <td class="clickable" id="status<?=$r['id'];?>" onclick="changeStatus('users/status.php?id=<?=$r['id'];?>',<?=$r['id'];?>)">
					    <?php if($r['status']==1){?><img src="assets/icons/tick.png" /><?php }else{ ?><img src="assets/icons/cross.png" /><?php } ?>
					   </td>
					   <td align="center"><input type='checkbox' name='checkbox[]' id='checkbox[]' value="<?php echo $r['id'];?>" style="width:50px;" /></td>
					  </tr>
					<?php } ?>
	             </tbody>
             </table>