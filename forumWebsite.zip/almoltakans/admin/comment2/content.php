<div id="main-content">
   <div id="indicator"><strong>Logged in as : <?php echo $fgmembersite->UserFullName(); ?></strong>  </div>
 <div id="left-menu">
	   <?php include('includes/leftmenu.php'); ?>
 </div>
 <div id="pagecontent">
  <div id="content-left">
   <?php include('../db/db.php'); ?>
   <div class="top_link">
   <div class="left_link">
    <a href="javascript:backpage()" class="backbutton">Back</a>
   </div>

  </div>
   <form method='post' action='comment2/slider-delete.php' name="deleteForm" id="deleteForm">
     <div class="demo_jui" id="content_table">
          <?php include "comment2/table.php";?>
	 </div>
    <input id='delete' type='submit' class='button' name='delete' value='Delete Selected Items' onclick="return confirm('Do you wish to Delete Items?')"/>
   </form>
	</div>
     
 </div>
</div>

