<?php
include('../../db/db.php');
include ('../includes/thumb.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$title_ar=secureInput($_POST['title_ar']);
    $content=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content']);
    $content_ar=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content_ar']);
	$status=secureInput($_POST['status']);

	//secureInput($_POST['page_s']);

		$q6=mysql_query("insert into  aboutus (title, title_ar, status, content, content_ar) values('$title','$title_ar','$status','$content', '$content_ar')") or die(mysql_error());
		echo'<div class="success">Content was added successfully.</div>';
}

?>