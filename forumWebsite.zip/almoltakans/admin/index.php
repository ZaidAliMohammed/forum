<?PHP
require_once("include/membersite_config.php");
if(isset($_POST['submitted']))
{
   if($fgmembersite->Login())
   {
        $fgmembersite->RedirectToURL("header.php");
   }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Browse ME, Index</title>
<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<link rel="shortcut icon" href="../assets/icons/logo.png" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/reset.css" />
<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
<link rel="stylesheet" href="assets/css/jquery.dataTables.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="assets/css/fancybox.css" />
<script type="text/javascript" src="assets/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" language="javascript" src="assets/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="assets/js/ajax.js"></script>
<script type='text/javascript' src='assets/js/jquery.form.js'></script>
<script src="assets/js/fancybox.js" language="javascript"></script>
<script type="text/javascript">
$(document).ready(function() { 
	$('#listcontent').dataTable( {
      "aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 6 ] }
       ]
});
    $('#AddNew').ajaxForm({ 
        target: '#preview', 
        success: function(response) { 
            	$('#preview').fadeIn();
        }
    });
});
function checkAll(){  
    var field = document.getElementsByName('checkbox[]');
	for (i = 0; i < field.length; i++)
 		if(document.deleteForm.CheckAll.checked == true){
		field[i].checked = true ;
	}else{
		field[i].checked = false ;
	}	
}
</script>
<style>
label{color:#71be0f; font-weight:bold;}
.error{ padding:0;}
.submitlogin{background:none; color:#434244; font-size:16px;border:none;padding:0; float:right; margin-right:65px; margin-top:-20px; cursor:pointer;}
</style>
</head>
<body class="index">
<?php
require_once('includes/header-index.php');
?>
		
		<div id="contentlogin">
		<form id='login' action='<?php echo $fgmembersite->GetSelfScript(); ?>' method='post' accept-charset='UTF-8'>
			<input type='hidden' name='submitted' id='submitted' value='1'/>
            <div class="login_top">Welcome to - Almoltakans</div>
			 <div>
			 <div><span class='error'><?php echo $fgmembersite->GetErrorMessage(); ?></span></div>
			<span id='login_username_errorloc' class='error'></span>
			</div>
    
			<div>
			<span id='login_password_errorloc' class='error'></span>
			</div>
			<input type='text' name='username' id='username' value='Email or user name'
            onfocus="if(this.value=='Email or user name'){this.value=''}else{this.select()}"
            onblur="if(this.value==''){this.value='Email or user name'}"
            class="inptindex" />
				  <input type='password' name='password' id='password' class="inptindex" />
                  <br />
				 <input type='submit' name='Submit' value='Login' class="submitlogin" />
		
			</form>
		</div>
<?php
require_once("includes/footer.php"); 
?>
</body>
</html>

<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("login");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req","Please provide your username");
    
    frmvalidator.addValidation("password","req","Please provide the password");

// ]]>
</script>
