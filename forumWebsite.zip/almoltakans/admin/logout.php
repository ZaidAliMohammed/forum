<?PHP
require_once("include/membersite_config.php");

$fgmembersite->LogOut();

header('Location: index.php');
?>