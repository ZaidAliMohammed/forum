<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$title=($_POST['title']);
$title_ar=($_POST['title_ar']);
$status=secureInput($_POST['status']);
$content=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content']);
$content_ar=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content_ar']);
if($title =='' || $title_ar ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `ourwork` set title='$title', title_ar='$title_ar', content='$content', content_ar='$content_ar'  where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>