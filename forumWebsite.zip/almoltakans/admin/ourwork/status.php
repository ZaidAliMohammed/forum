<?php
include_once '../../db/db.php';
if(isset($_POST['id'])) { 
$id = intval($_POST['id']); 
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {						
$q3 = mysql_query("SELECT * FROM ourwork WHERE `id`='$id'");
$r3=mysql_fetch_array($q3);
	
if($r3['status']=='1'){
	$q4 = mysql_query("UPDATE ourwork SET `status`='0' WHERE `id`='$id'");
	echo '<img src="assets/icons/cross.png" />';
}else{
	$q5 = mysql_query("UPDATE ourwork SET `status`='1' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';
}					
}
}
?>