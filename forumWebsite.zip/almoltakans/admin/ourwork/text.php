<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>
<style>
body{
	font-family:arial;
}
form, h2{
	padding:0;
	margin:0;
}	
.ifp{
	width:450px;
}
.ifp:after{
	content:'.';display:block;clear:both;visibility:hidden;height:0;
}
.ifpl{
	float:left;
	width:120px;
	font-size:10pt;
	color:#333;
}
.ifpr{
	float:left;
	width:300px;
	margin-left:10px;
}
.ifpr input{
	font-size:10pt;
	color:#333;
}
.ifpr textarea{
	width:300px;
	height:200px;
	font-size:10pt;
	color:#333;
}
.faraghifp{
	width:1px;
	height:20px;
}
.ifpm{
	height:30px;
	font-size:10pt;
	color:#333;
	line-height:20px;
}
</style>
</head>
<body>
<?php
include_once('../../db/db.php');
if(isset($_GET['id'])) { 
$id = intval($_GET['id']);
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {	
$q = mysql_query("select * from ourwork where id=$id");
$r = mysql_fetch_array($q);
?>
<h2><?php echo $r['title']; ?></h2>
<div class="ifp">
<?php echo $r['content']; ?>
</div>

<?php }?>
<div class="ifp">
	<div class="ifplb">
    </div>
</div>
<?php
}
?>
</body>
</html>
